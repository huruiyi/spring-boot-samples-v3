package com.justahmed99.authapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthAppApplication {

  public static void main(String[] args) {
    SpringApplication.run(AuthAppApplication.class, args);
  }

}
